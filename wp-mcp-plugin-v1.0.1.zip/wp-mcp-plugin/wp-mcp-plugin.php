<?php
/**
 * Plugin Name: MCP WordPress Integration
 * Plugin URI: https://monopolygowin.com
 * Description: Provides MCP server integration for WordPress and WooCommerce control
 * Version: 1.0.1
 * Author: MonopolyGoWin
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MCP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('MCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MCP_API_NAMESPACE', 'mcp/v1');

// Include required files
require_once MCP_PLUGIN_PATH . 'includes/api-endpoints.php';
require_once MCP_PLUGIN_PATH . 'includes/auth.php';

// Initialize the plugin
add_action('init', 'mcp_init');
function mcp_init() {
    // Any initialization code here
}

// Register REST API endpoints
add_action('rest_api_init', 'mcp_register_api_endpoints');

// Add admin menu
add_action('admin_menu', 'mcp_add_admin_menu');
function mcp_add_admin_menu() {
    add_menu_page(
        'MCP Integration',
        'MCP Integration',
        'manage_options',
        'mcp-integration',
        'mcp_admin_page',
        'dashicons-rest-api',
        90
    );
}

// Admin page
function mcp_admin_page() {
    ?>
    <div class="wrap">
        <h1>MCP WordPress Integration</h1>
        
        <div class="card">
            <h2>Connection Status</h2>
            <p>MCP Server can connect to your WordPress site using Application Passwords.</p>
            
            <h3>Setup Instructions:</h3>
            <ol>
                <li>Go to Users → Your Profile</li>
                <li>Scroll down to "Application Passwords"</li>
                <li>Enter "MCP Server" as the name</li>
                <li>Click "Add New Application Password"</li>
                <li>Copy the generated password</li>
                <li>Add it to your MCP server config.json</li>
            </ol>
        </div>
        
        <div class="card">
            <h2>Available Endpoints</h2>
            <p>The following custom endpoints are available:</p>
            <ul>
                <li><code>/wp-json/mcp/v1/templates</code> - List theme templates</li>
                <li><code>/wp-json/mcp/v1/templates/read</code> - Read template content</li>
                <li><code>/wp-json/mcp/v1/templates/update</code> - Update template content</li>
                <li><code>/wp-json/mcp/v1/system/info</code> - Get system information</li>
            </ul>
        </div>
    </div>
    <?php
}

// Activation hook
register_activation_hook(__FILE__, 'mcp_activate');
function mcp_activate() {
    // Create any necessary database tables or options
    add_option('mcp_plugin_version', '1.0.0');
    
    // Flush rewrite rules to ensure our endpoints work
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'mcp_deactivate');
function mcp_deactivate() {
    // Cleanup
    flush_rewrite_rules();
}
